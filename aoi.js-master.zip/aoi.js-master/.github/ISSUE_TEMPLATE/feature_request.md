---

name: Feature request
about: Request feature about function, callback, handler, etc for aoi.js
title: ''
labels: 'type: enhancement'
assignees: ''
---
<!-- Use Discord for questions: https://discord.gg/HMUfMXDQsV -->

## Type
- [ ] Functions: \<Function Name>
- [ ] Callbacks: \<Callback Name>
- [ ] Handlers: \<Handler Type>
- [ ] Others: \______

## Description
Explain how it works