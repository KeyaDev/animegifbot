module.exports = (client, channel) => {
    require("../handlers/channelDeleteCommands") (client, channel) 
}