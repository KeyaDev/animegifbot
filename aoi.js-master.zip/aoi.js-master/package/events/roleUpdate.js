module.exports = (client, oldr, newr) => {
    require("../handlers/roleUpdateCommands")(client, oldr, newr) 
}