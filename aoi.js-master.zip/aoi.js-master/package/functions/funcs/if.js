module.exports = async d => {
 return d.error(`:x: Wrong usage of \`$if\` function!`)
}